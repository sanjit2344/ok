package com.example.taskmeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import java.lang.String;
/*
Adding a comment to make sure I am able to push to the repo - delete later
 */

//this comment should be in marcelo branch

public class MainActivity extends AppCompatActivity {
    Textview textview;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    textView = (TextView)findViewById(R.id.textView);

public class Task implements comparable<task>{
    private static final String task_name;
    private static final String due_date;
    private static final String category;
    private static final String completed_date;

    public Task(String task_name,String due_date, String category, String completed_date){
        this.task_name = task_name;
        this.due_date = due_date;
        this.category = category;
        this.completed_date = "";
    }
    public static String getTask_name() {

        return task_name;
    }
    public static String getDue_date() {

        return due_date;
    }
    public static String getCategory() {

        return category;
    }
    public static String getCompleted_date() {

        return completed_date;
    }
    public String toString() {
        if (completed) {
            return "Task: " + task_name + "\n" + "Completed: " + completed_date + "\n" + "Category: "
                    + category;
        } else {
            return "Task: " + task_name + "\n" + "Due: " + due_date + "\n" + "Category: " +
                    category;
        }
    }
}

    public void setName (String name ) {
        this.task_name = name;
    }

    public void setDuedate(String duedate) {
        this.due_date = duedate;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    public void setCompletedDate(String completedDate) {
        this.completed_date = completedDate;
    }




    textView.setText("");

    textView.append(task_name);
    textView.append(due_date);
    textView.append(category);
    textView.append(completed_date);


}
 